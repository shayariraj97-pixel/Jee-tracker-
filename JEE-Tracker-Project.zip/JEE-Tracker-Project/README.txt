JEE TRACKER - APP + HOME SCREEN WIDGETS (Android tablet, no PC needed)
=======================================================================

WHAT IS IN THIS ZIP
  index.html                    The whole tracker app
  debug.keystore                Keeps every build signed the same (updates install over the old app)
  build.yml                     The build recipe (a copy, easy to open and copy-paste)
  .github/workflows/build.yml   The same recipe in the folder GitHub needs (hidden folder)
  README.txt                    This guide

WHAT YOU GET AT THE END
  1. The tracker installed as a real app with its own icon.
  2. Two home-screen widgets that stay on your home screen all the time:
     - JEE Quote Card : white card with pink/red stripes, big outlined quote,
       dots at the bottom. Quote changes every 8 seconds. Tap the card = next quote.
       Small "JEE" chip (top right) opens the app.
     - JEE Pictures   : quotes over pictures, with days left, today's habits, streak.

HOW IT WORKS (simple)
  You cannot make an Android app on the tablet itself, so GitHub (free website)
  builds it for you from these files. You upload the files, GitHub makes an APK
  (the install file) in about 5-10 minutes, you download it and install it.

STEP 0 - GET READY
  - Open this zip in My Files and tap Extract. You now have the files.
  - Open Chrome. Tap the 3 dots and turn ON "Desktop site" (GitHub's phone layout hides menus).

STEP 1 - GITHUB ACCOUNT
  - Go to github.com, tap Sign up, enter email + password + username, verify the email code.

STEP 2 - CREATE A REPOSITORY (project folder)
  - Tap  +  (top right) -> New repository
  - Name: jee-tracker      Choose: Public      Tick: Add a README file
  - Tap Create repository

STEP 3 - UPLOAD 2 FILES
  - Tap Add file -> Upload files
  - Pick index.html and debug.keystore (from the extracted folder). Select both.
  - Wait until both are uploaded, tap Commit changes.
  - They must be in the main page of the repository, not in a folder.

STEP 4 - CREATE THE BUILD FILE
  - Tap Add file -> Create new file
  - In the name box type exactly:   .github/workflows/build.yml
    (each "/" makes a folder: you should see .github, then workflows)
  - Open build.yml from the extracted folder in a text app, Select all, Copy,
    and Paste it in the big box.
  - Tap Commit changes, then Commit changes again.

STEP 5 - WATCH THE BUILD
  - Open the Actions tab. If asked, tap the green button to enable workflows.
  - Tap "Build JEE Tracker APK" on the left. If no run started, tap
    Run workflow -> Run workflow.
  - Yellow dot = running, green tick = done, red cross = failed.
  - Wait 5-10 minutes.
  - If red: tap the run, tap the red step, take a screenshot and send it to Claude.

STEP 6 - DOWNLOAD THE APP
  - Go to the Code tab -> Releases (right side) -> newest build -> Assets
  - Tap  app-debug.apk  to download.

STEP 7 - INSTALL
  - Open My Files -> Downloads -> tap app-debug.apk (open it from My Files, not from Chrome).
  - Allow "Install unknown apps" for My Files when asked, then tap Install.
  - Samsung may block it: Settings -> Security and privacy -> Auto Blocker -> turn OFF for now.
  - Play Protect warning: tap Install anyway (normal for apps you build yourself).
  - OPEN THE APP ONCE.

STEP 8 - PUT THE WIDGET ON YOUR HOME SCREEN
  - Long-press an empty spot on the home screen.
  - Tap Widgets -> find "JEE Quote Card" (and/or "JEE Pictures") -> drag it to the screen.
  - Long-press the widget to resize it.
  - A widget stays on the home screen all the time. It is not closed when you close the app.
  - If your home layout is locked: Settings -> Home screen -> Lock home screen layout -> OFF.
  - If the widget looks old after an update: remove it and add it again.

UPDATING LATER
  - On GitHub open the file (for example index.html), tap the pencil icon,
    select all, paste the new version, tap Commit changes.
  - A new build starts by itself. Download the new app-debug.apk from Releases and
    install it over the old app. Your data stays (because of debug.keystore).
  - If you built the app BEFORE uploading debug.keystore, the first update says
    "App not installed": uninstall once, install the new one (this clears saved ticks).

THINGS YOU CAN CHANGE (all in index.html)
  - Exam date for widget countdown : the line starting  var EXAM=   (format YYYY-MM-DD).
    It is a placeholder (2028-01-24).
  - Points and priority weights    : the line starting  var WT=
  - Quotes (app and widgets)       : the list starting   var QD=[
  - Your custom habit              : tap its name in the app (start with an emoji if you like)

TROUBLESHOOTING
  Chrome says "Your file couldn't be accessed" : the file was moved/deleted. Download again
        from Releases and open it from My Files.
  No "Build JEE Tracker APK" in Actions : the path must be exactly .github/workflows/build.yml
  Build is red                          : send a screenshot of the red step to Claude.
  No Releases section                   : the build is not green yet. Check Actions.
  "App not installed"                   : see UPDATING LATER above.
  Widget empty                          : open the app once, then remove and add the widget again.
  Quotes do not change by themselves    : some launchers pause animations. Tap the card
        for the next quote, and tell Claude so the method can be changed.
  Fonts look different offline          : fonts load from the internet; offline it uses default fonts.

GOOD TO KNOW
  - Your ticks and habits are saved only inside the app on your tablet.
    Uninstalling removes them. There is no backup button yet (ask Claude to add one).
  - This is a debug app for personal use, not from the Play Store.
  - Free: public GitHub repositories build for free with no time limit.
